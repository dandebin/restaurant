﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Restaurant
{
    public partial class ScanResult : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                lblResult.Text = "支付失败";
                string p = Request.Params["p"];
                if (!string.IsNullOrEmpty(p))
                {
                    string[] a = p.Split('/');
                    if (a.Length > 2)
                    {
                        lblName.Text = a[1];
                        lblAmount.Text = a[2];
                        lblResult.Text = "支付成功";
                    }
                }
               
                
            }
        }
    }
}