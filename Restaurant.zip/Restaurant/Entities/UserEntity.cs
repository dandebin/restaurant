﻿using Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entities
{
    public class UserEntity
    {
        public bool RegisterUser(UserInfo user)
        {
            using (var db = new SwingDataContext())
            {
                db.User.InsertOnSubmit(new User()
                {
                    UserName=user.Name,
                    Email = user.Email,
                    Status = false,
                    TypeID = 1,
                    CreateDate = DateTime.Now
                });
                db.SubmitChanges();
            }
            return true;
        }
    }
}
